import PublicRoutes from './routes/public-routes';
import '../public/assets/css/style.css';

function App() {
  return <PublicRoutes />;
}

export default App;

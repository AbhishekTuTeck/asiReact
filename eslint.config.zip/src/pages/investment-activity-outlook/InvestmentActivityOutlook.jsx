import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Button from "react-bootstrap/Button";

export default function InvestmentActivityOutlook() {
  return (
    <>
      <Form className="siteForm">
        <div className="d-flex mb-2">
          <h3 className="page-title">Investment Activity Outlook</h3>
          <Button variant="light">
            Save & Continue <i class="bi bi-arrow-right-short"></i>
          </Button>
        </div>
        <Card className='questionCard mb-3'>
          <Card.Body>
            <Card.Title><span className='Count'>11</span> <h5>Assets Purchasing Activity Expectations In the next FY (e.g., 2025-26)</h5></Card.Title>
            <Row>
              <Form.Group as={Col} lg="4" md="6" sm="12">
                <Form.Label>Please Select</Form.Label>
                <Form.Select aria-label="Default select example">
                  <option>Buy More</option>
                  <option>About the same</option>
                  <option>Buy Less</option>
                  <option>No Intention To Buy</option>
                </Form.Select>
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>
              <Form.Group as={Col} lg="4" md="6" sm="12">
                <Form.Label>Please Select (Buy More / Buy Less)</Form.Label>
                <Form.Select aria-label="Default select example">
                  <option>More Than 10% Higher</option>
                  <option>Upto 10% Higher</option>
                  <option>More Than 10% Lower</option>
                  <option>Upto 10% Lower</option>
                </Form.Select>
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>
            </Row>
          </Card.Body>
        </Card>
        <Card className='questionCard mb-3'>
          <Card.Body>
            <Card.Title><span className='Count'>12</span> <h5>Asstes Selling Activity Exceptions in the next FY (e.g., 2025-26)</h5></Card.Title>
            <Row>
              <Form.Group as={Col} lg="4" md="6" sm="12">
                <Form.Label>Please Select</Form.Label>
                <Form.Select aria-label="Default select example">
                  <option>Sell More</option>
                  <option>About The Same</option>
                  <option>Sell Less</option>
                  <option>No Intention To Sell</option>
                </Form.Select>
                <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
              </Form.Group>
            </Row>
          </Card.Body>
        </Card>
        <div className="footerBtnGroup d-flex justify-content-end">
          <div>
            <Button variant="primary" className="ms-2">
              Save & Continue <i class="bi bi-arrow-right-short"></i>
            </Button>
          </div>
        </div>
      </Form>
    </>
  );
}
